# Visual aplicado a todas as páginas

O visual do repositório `1ucasxz/sense-vision-website` foi aplicado ao frontend de `kao04/sensevision` (base 92ef9a9), preservando a estrutura `front/`, `backend/`, `raspberry/` e `docs/`.

## Páginas

Início, Instruções, Produto, Equipe, Referências, apresentação do jogo, Simulador, Histórico e Jogar usam o mesmo design: tipografia Inter, paleta ciano/rosa, componentes, cabeçalho, rodapé e temas claro/escuro. O jogo gerado não foi redesenhado; somente sua página externa recebeu o visual.

## Estilos ativos

- `css/design.css`: tokens, componentes e layouts compartilhados.
- `css/features.css`: acesso de conta, simulador, histórico e jogo.
- `css/icons.css`: ícones vetoriais.
- `css/visual.css`: representações pedagógicas do simulador.

Os estilos antigos permanecem no pacote para referência, mas não são carregados pelas nove páginas. Não volte a incluir `style.css`, `dark.css`, `responsive.css` ou `auth.css` junto ao novo design: isso causa conflitos visuais.

## Funcionalidades preservadas

IDs usados pelo simulador e histórico, atributos dos controles, rotas `/api/*`, ordem dos scripts, jogo embarcado, tema persistente e formulário FormSubmit. Os ajustes de JavaScript são de apresentação e interação: ícones SVG, menu, foco do diálogo e acessibilidade. O formulário mantém o destinatário indicado pelo responsável do site: lucas2008barboza@gmail.com.

Backend, banco de dados, código Raspberry e arquivos gerados do jogo não foram modificados nesta aplicação visual. O backend original ainda aponta os assets para `../sense-vision-website` em `backend/cloud/wrangler.toml`; ao publicar esta estrutura, o responsável deve configurar o diretório do frontend como `../../front`. Não inclua segredos no frontend.

## Prévia

Na raiz do repositório: `python3 -m http.server 5175 --bind 127.0.0.1 --directory front`.
Abra http://127.0.0.1:5175/index.html.

Essa prévia é estática: login, histórico e câmera precisam do backend configurado para operar. O simulador funciona localmente. A ativação do destinatário no FormSubmit continua necessária; não foi enviada mensagem de teste.

## Verificação

As nove páginas foram verificadas a 375, 820, 1280 e 1440 pixels, nos temas claro e escuro: 72 combinações, sem transbordamento horizontal ou imagens quebradas. O cabeçalho apresentou a mesma altura entre páginas em cada largura. Testes locais anteriores validaram operações matemáticas e a API de cadastro/login/histórico; câmera real e publicação não foram testadas nesta etapa.

Não foi realizado push, commit nem deploy. Consulte `ARQUIVOS-ALTERADOS.txt` para a relação de alterações em relação à base do repositório novo.
